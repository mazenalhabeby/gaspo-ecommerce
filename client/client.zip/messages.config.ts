const messagesConfig = {
  locales: ["en", "de"],
  defaultLocale: "en",
}

export default messagesConfig
